package services;

import java.util.ArrayList;
import java.util.List;

import controller.Controller;
import model.entity.reserva;
import model.entity.usuario;

public class service_reserva {
			
		Controller vCtrl = new Controller();
	
//		public reserva pesquisaId(int id){
//			List<usuario> auxUser = new ArrayList<usuario>();
//			auxUser = vCtrl.ListaUsuario();
//			usuario user;
//			for(usuario user: auxUser){
//				if(user.getId() == id){
//					
//				}
//			}
//		}
}
