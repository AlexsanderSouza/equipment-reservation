package model.entity;

public class restricaoRecurso {
	int id, id_tipo_recurso, id_funcao;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId_tipo_recurso() {
		return id_tipo_recurso;
	}

	public void setId_tipo_recurso(int id_tipo_recurso) {
		this.id_tipo_recurso = id_tipo_recurso;
	}

	public int getId_funcao() {
		return id_funcao;
	}

	public void setId_funcao(int id_funcao) {
		this.id_funcao = id_funcao;
	}
	
	
}
